<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Pluralizer;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\Artisan;

class MakeWholeCrudCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'MakeWholeCrud:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate the crud of selected project according to the database';

    /**
     * Filesystem instance
     * @var Filesystem
     */
    protected $files;

    /**
     * Create a new command instance.
     * @param Filesystem $files
     */
    public function __construct(Filesystem $files)
    {
        parent::__construct();

        $this->files = $files;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Récupération de toutes les tables 
        $tables = DB::select('SHOW TABLES');
        $nbTables = count($tables);
               
        // Création (composition) du nom du fichier (class) à créer 
        $path = $this->getSourceFilePath('layout');

        // Création du répertoire du fichier(class)  si inexistant 
        $this->makeDirectory(dirname($path));
        // Récupération du contenu du fichier complet modifié
        $contents = $this->getSourceFile();
    
        $this->info("Creating view layout file");
        // Création du layout
        if (!$this->files->exists($path)) {
            $this->files->put($path, $contents);
            $this->info("File : {$path} created");
        } else {
            $this->info("File : {$path} already exits");
        }

        // Création des models
        $this->info("Creating Model files for all tables");
         //Initialisation de la progresse bar
        $bar = $this->output->createProgressBar($nbTables);
        $bar->start();
        foreach ($tables as $table) {
            foreach ($table as $key => $table_name){
                Artisan::call("ModelCrud:generate $table_name ");
            }
            $bar->advance();
        }
        //Fin de la progresse bar
        $bar->finish();
        //Fin Création des models

        // Création des Controllers
        $this->info("");
        $this->info("Creating Controller files for all tables");
         //Initialisation de la progresse bar
        $bar = $this->output->createProgressBar($nbTables);
        $bar->start();
        foreach ($tables as $table) {
            foreach ($table as $key => $table_name){
                Artisan::call("ControllerCrud:generate $table_name ");
            }
            $bar->advance();
        }
        //Fin de la progresse bar
        $bar->finish();
        //Fin Création des Controllers


        // Création des differentes vues
        $this->info("");
        $this->info("Creating view files for all tables");
            //Initialisation de la progresse bar
        $bar = $this->output->createProgressBar($nbTables);
        $bar->start();
        foreach ($tables as $table) {
            foreach ($table as $key => $table_name){
                Artisan::call("MakeIndexView:generate $table_name ");
                Artisan::call("MakeCreateView:generate $table_name ");
                Artisan::call("MakeEditView:generate $table_name ");
            }
            $bar->advance();
        }
        //Fin de la progresse bar
        $bar->finish();
        //Fin Création des differentes vues
        


        return 0;
    }

    /** 
    * Renvoie le nom en majuscule singulier 
    * @param $name 
    * @return string 
    */ 
    public function getClassName($name) 
    { 
        //On partage les différents segments de la chaîne
        $MyVar = explode("_",$name);
        $ClassName = "";
        //on convertit les premières lettre  de chaque segment en majuscule
        foreach($MyVar as $var){
            $ClassName .= ucwords($var);
        }
        // return ucwords(Pluralizer:: singular ($name)); 
         return $ClassName; 
    }

    /** 
    * Renvoie le chemin du fichier stub 
    * @return string 
    * 
    */ 
    public function getStubPath() 
    { 
        return __DIR__ . '/../../../stubs/views/layout.stub'; 
    }


    /** 
    ** 
    * Mappez les variables de stub présentes dans stub à sa valeur 
    * 
    * @return array 
    * 
    */ 
    public function getStubVariables() 
    { 
        return [ 
            // 'NAMESPACE' => 'App\\Interfaces', 
            // '{{class}}' => $this->getClassName($this->argument('name')), 
            // '{{model}}' => $this->getClassName($this->argument('name')),
            // '{{modelVariable}}' => lcfirst($this->getClassName($this->argument('name'))),
            // '{{indexMethodContent}}' => $this->indexMethodContent($this->argument('name')),
            // '{{createMethodContent}}' => $this->createMethodContent($this->argument('name')),
            // '{{storeMethodContent}}' => $this->storeMethodContent($this->argument('name')),
            // '{{showMethodContent}}' => $this->showMethodContent($this->getClassName($this->argument('name'))),
            // '{{editMethodContent}}' => $this->editMethodContent($this->getClassName($this->argument('name'))),
            // '{{updateMethodContent}}' => $this->updateMethodContent($this->argument('name')),
            // '{{deleteMethodContent}}' => $this->deleteMethodContent($this->argument('name')),
            
        ] ; 
    }

    /**
     * Get the stub path and the stub variables
     *
     * @return bool|mixed|string
     *
     */
    public function getSourceFile()
    {
        return $this->getStubContents($this->getStubPath());
    }


    /**
     * Replace the stub variables(key) with the desire value
     *
     * @param $stub
     * @param array $stubVariables
     * @return bool|mixed|string
     */
    public function getStubContents($stub)
    {
        $contents = file_get_contents($stub);

        // foreach ($stubVariables as $search => $replace)
        // {
        //     $contents = str_replace($search , $replace, $contents);
        // }

        return $contents;

    }

    /**
     * Get the full path of generated class
     *
     * @return string
     */
    public function getSourceFilePath($filename)
    {
        return base_path('resources\\views') .'\\' . $filename.'.blade.php';
    }

    /**
     * Build the directory for the class if necessary.
     *
     * @param  string  $path
     * @return string
     */
    protected function makeDirectory($path)
    {
        if (! $this->files->isDirectory($path)) {
            $this->files->makeDirectory($path, 0777, true, true);
        }

        return $path;
    }

    

  
}
